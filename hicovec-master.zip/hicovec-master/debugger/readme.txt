there is a python library required for RS232 connection.
 As its not liscensed under GPL you'll have to download it
yourself from: http://pyserial.sourceforge.net/